#ifndef GOODBYE_H
#define GOODBYE_H

void goodbye(void);

#endif
